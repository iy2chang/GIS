/*
 * @(#)ObjectIds.java	1.7 01/12/04
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

//Source file: J:/ws/serveractivation/src/share/classes/com.sun.corba.se.internal.ior/ObjectIds.java

package com.sun.corba.se.internal.ior;

import java.util.LinkedList ;

/** This class represents a container of ObjectId instances.
 * @author 
 */
public class ObjectIds extends LinkedList {}
